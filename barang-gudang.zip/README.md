# Web Aplikasi Inventory Gudang

Web aplikasi inventory gudang ini di buat memakai framework codeigniter yang sangat sederhana

# User database
<strong>Admin</strong><br>
Username : admin<br>
Password : admin

<strong>User Biasa</strong><br>
Username : husni<br>
Password : 123husni

# ScreenShot 
<a href="https://drive.google.com/drive/folders/1-pOxHNzg4o_m0TClvvNhLFMJ-T1IvQsK?usp=sharing">All ScreenShot</a>
